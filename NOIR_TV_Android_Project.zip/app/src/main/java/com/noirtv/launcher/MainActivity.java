package com.noirtv.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(3,5,12), BLUE = Color.rgb(0,130,255);
    private LinearLayout root, grid;
    private final ArrayList<View> tiles = new ArrayList<>();
    private int focused = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUI();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(26);
        if (stroke > 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUI() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(34,22,34,24); root.setBackgroundColor(BG);
        setContentView(root);

        TextView nav = text("⌂  Inicio        ▦  Aplicaciones        ▣  Series        ◉  Películas        ⚙  Configuración", 20, true);
        nav.setGravity(Gravity.CENTER_VERTICAL); nav.setPadding(8,8,8,22);
        root.addView(nav, new LinearLayout.LayoutParams(-1, 58));

        TextView welcome = text("Bienvenido", 38, true);
        root.addView(welcome);
        TextView sub = text("Disfruta de tus aplicaciones favoritas", 18, false);
        sub.setTextColor(0xFFBFC8DA); root.addView(sub);

        View accent = new View(this); accent.setBackground(shape(BLUE,0));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(90,5); ap.setMargins(0,18,0,20);
        root.addView(accent,ap);

        ScrollView scroll = new ScrollView(this);
        grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(grid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        loadApps();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(query,0);
        Collections.sort(apps, (a,b) -> String.CASE_INSENSITIVE_ORDER.compare(
            a.loadLabel(pm).toString(), b.loadLabel(pm).toString()));

        ArrayList<android.content.pm.ResolveInfo> filtered = new ArrayList<>();
        for (android.content.pm.ResolveInfo ri : apps) {
            String pkg = ri.activityInfo.packageName;
            if (!pkg.equals(getPackageName())) filtered.add(ri);
        }

        LinearLayout row = null; int count = 0;
        for (android.content.pm.ResolveInfo ri : filtered) {
            if (count % 5 == 0) {
                row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1,150);
                rp.setMargins(0,8,0,12); grid.addView(row,rp);
            }
            final String pkg = ri.activityInfo.packageName;
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER);
            tile.setBackground(shape(0xFF101522,0xFF28344C));
            tile.setFocusable(true); tile.setFocusableInTouchMode(true);
            ImageView icon = new ImageView(this);
            try { icon.setImageDrawable(ri.loadIcon(pm)); } catch(Exception ignored) {}
            tile.addView(icon,new LinearLayout.LayoutParams(54,54));
            TextView label = text(ri.loadLabel(pm).toString(),14,true);
            label.setGravity(Gravity.CENTER); label.setMaxLines(2);
            tile.addView(label);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,-1,1);
            tp.setMargins(5,0,5,0); row.addView(tile,tp);
            tiles.add(tile);
            tile.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) startActivity(launch);
            });
            tile.setOnFocusChangeListener((v, has) ->
                v.setBackground(shape(has ? 0xFF071B38 : 0xFF101522, has ? 0xFF168BFF : 0xFF28344C)));
            count++;
        }
        if (tiles.size() > 0) tiles.get(0).requestFocus();
        if (filtered.isEmpty()) {
            TextView empty = text("No se encontraron aplicaciones instaladas.",18,false);
            grid.addView(empty);
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true;
        return super.onKeyDown(keyCode,event);
    }
}
